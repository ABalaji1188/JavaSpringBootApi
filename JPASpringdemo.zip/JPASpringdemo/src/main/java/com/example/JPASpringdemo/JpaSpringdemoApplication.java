package com.example.JPASpringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaSpringdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaSpringdemoApplication.class, args);
	}

}
