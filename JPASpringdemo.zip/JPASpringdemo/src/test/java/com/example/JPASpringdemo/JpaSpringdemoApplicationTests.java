package com.example.JPASpringdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaSpringdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
